print("hello from python :)")
